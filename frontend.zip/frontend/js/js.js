function verificaUsuario(){
     $.ajax({
        url:'http://143.106.241.1/var/www/cl18464/daw/api/backend/consultaUsuario.php',
        dataType:'json',
        data:{
            usuario:$('#usuario').val(),
            senha:$('#senha').val(),
        },
        success:function(r){
             console.log(r);
             if(r.Resp==1){
                alert('Seja bem vindo(a)\n'+r.Nome,null,'Sucesso','Done');
                localStorage.setItem('Cod',r.Cod);
                localStorage.setItem('Nome',r.Nome);
                localStorage.setItem('Email',r.Email);
                localStorage.setItem('Perfil',r.Perfil);
            }
             else
                alert('Usuario/Senha inválido!',null,'Falha');
       },
        error:function(e){
            alert('Houve um erro de conexão com o banco de dados!!!',null,'Erro');
            console.log(e);
        }
    })
}