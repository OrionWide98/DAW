<?php
error_reporting(E_ALL);
ini_set("display_errors", 1);


header('Content-type: application/json');
header('Access-Control-Allow-Origin:*');

$user = $_REQUEST['usuario'];
$pwd = $_REQUEST['senha'];

if($user!="admin" || $pwd!='nimda'){
    $resposta = array('Resp'=>'0');
}else{
    $resposta = array('Resp'=>'1',
                        'Cod'=>'0',
                        'Nome'=>'Administrador',
                        'Email'=>'admin@empresa.com',
                        'Perfil'=>'logo.jpg'
                    );
}

ob_clean();

echo json_encode($resposta);

?>