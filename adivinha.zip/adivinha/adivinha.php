<!DOCTYPE html>
<html>
<head>
	<title>Adivinhe o Número!</title>
	<style type="text/css">
		*{
			color: #483D8B;
		}

		body{
 			margin-left: 30%;
 			font-family: 'Arial';
 			background-color: #ADD8E6;
		}
		p{
			font-size: 20px;
			font-weight: bold;
		}

		div#principal{
			margin-top: 15%;
			border: 10px solid #66CDAA;
			text-align: center;
			margin-right: 50%;
			padding: 10px 10px 70px 10px;
		}
		p#certo{
			color: green;
		}

		p.errado{
			color: red;
		}

		input[type='submit']{
			color: #000080;
			font-size: 20px;
			font-weight: bold;
		}

		input[type='text']{
			background-color: #87CEFA;
			border-color: #87CEFA;
		}
	</style>
</head>
<body>

	<div id='principal'>
		<p style="color: #000080;">Jogo adivinhe um número!</p>
		<p>Selecionamos um número aleatório entre 1 e 100. Veja se consegue adivinhar em 10 chances ou menos. Lhe diremos se seu palpite está com valor alto ou baixo.</p>

		<form method="post">
			<p>Palpite: <input type="text" name="palpite"></p>
			<input type="submit" value="Palpitar">

			<?php
				//criar sessão do user
				session_start();

				if (!isset($_SESSION['tentativa'])) {
					$_SESSION['tentativa'] = 0;
					$_SESSION['numero_gerado'] = rand(1, 100);
					$_SESSION['anteriores'] = "Tentativas Anteriores: ";
				}

				#echo $_SESSION['numero_gerado'];

				if (isset($_POST['palpite'])) {
					$palpite = $_POST['palpite'];

				if ($_SESSION['tentativa'] < 10) {
					
					if (!$palpite == "") {
					$_SESSION['anteriores'] .= $palpite.", ";
					echo "<p>".$_SESSION['anteriores']."</p>";

					if ($palpite == $_SESSION['numero_gerado']) {
						echo "<p id='certo'>Parabéns! Você acertou com ".$_SESSION['tentativa']." tentativas </p>";
						session_destroy();
						echo "<p><input type='submit' value='Recomeçar'></p>";
					} elseif ($palpite < $_SESSION['numero_gerado']) {
						echo "<p class='errado'>Seu palpite está abaixo do número sorteado!</p>";
					} else {
						echo "<p class='errado'>Seu palpite está acima do número sorteado</p>";
					}
				}
					$_SESSION['tentativa']++; 
				} else{
						echo "<p class='errado'>Você já usou suas 10 tentativas!</p>";
						session_destroy();
						echo "<p><input type='submit' value='Recomeçar'></p>";
					}
				}
			?>
		</form>
	</div>
</body>
</html>
