<?php
	// inicializa as variável de sessão que armazenarão as informações que não sumirão ao atualizar a página.
	session_start();

	// opção de resetar o jogo. Como o _GET não existe sem clicar no botão reset, precisa verificar se ele existe para não dar erro.

	if (isset($_GET['reset'])) {
		if ($_GET['reset'] == 1) {
			session_destroy();
			// o session_destroy não apaga arrays de sessão!!
			unset($_SESSION['cartas']);
			unset($_SESSION['paresFormados']);
		}
	}

	// Aqui inicializa o jogo
	if (!isset($_SESSION['cartas'])) {
		// possui todas as figuras das cartas e suas posições.
		$_SESSION['cartas'] = array();

		// possui os pares formados. Como inicialmente não possui nenhum par formado, começa com 0.
		$_SESSION['paresFormados'] = array();

		// carregaremos todas as 20 cartas neste array. São 10 figuras diferentes.

		for ($i=1; $i <= 20; $i++) { 
			// como não existe 0.png, usamos if para mudar 0 para 10.

			if (($i%10) == 0) {
				array_push($_SESSION['cartas'], "10.png");
			} else{
				array_push($_SESSION['cartas'], ($i%10).".png");
			}

			array_push($_SESSION['paresFormados'], 0);
		}
		// misturar as cartas.

		shuffle($_SESSION['cartas']);

		// variáveis que controlam as duas cartas da jogada.
		$_SESSION['cartaVirada1'] = -1;
		$_SESSION['cartaVirada2'] = -1;

		// jogadas do jogo

		$_SESSION['jogadas'] = 0;
	}

	// variaveis para controle das cartas viradas (no clique das imagens)
	if (isset($_GET['cartaVirada1'])) {
	 	$_SESSION['cartaVirada1'] = $_GET['cartaVirada1'];
	 } 
	if (isset($_GET['cartaVirada2'])) {
	 	$_SESSION['cartaVirada2'] = $_GET['cartaVirada2'];
	}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
	<link rel="shortcut icon" type="image/x-icon" href="imagens/icone.ico">
	<title>Jogo da Memória</title>
	<style type="text/css">
		*{
			margin: 0;
			padding: 0;
		}

		h1{
			margin-top: 5px;
			text-align: center;
			font-style: italic;
			font-size: 50px;
			color: red;
			text-decoration: overline;
		}

		hr{
			margin-top: 10px;
			margin-left: 25%;
			margin-right: 25%;
			background-color: red;
			border-color: red;
		}

		form{
			margin-left: 29%;
			margin-top: 100px;
		}
		table{
			border-color: red;
		}

		input[type='button']{
			font-size: 15px;
			padding: 2px;
			margin-right: 10px;
			border-style: dashed;
			border-color: black;
		}		
	</style>
</head>
<body>
	<h1>Jogo da Memória do Chico!</h1>
	<hr size="5">
	<form method="post" name="form" id="form" action="<?php echo $_SERVER['PHP_SELF'];?>">
		<table border="2px">
			<tr>
				<?php
					// monta o tabuleiro
					for ($i=0; $i < 20; $i++) { 
						// pular linha a cada 5 cartas do tabuleiro
						if (($i%5==0)) {
							echo "</tr><tr>";
						}

						// se a posição do tabuleiro for cartaVirada1, cartaVirada2 ou virou par, ele mostra a carta, se não, mostra o ponto de interrogação (?)

						if (($i == $_SESSION['cartaVirada1']) || ($i == $_SESSION['cartaVirada2']) || ($_SESSION['paresFormados'][$i] == 1)) {
							// imagem que ele vai mostrar no tabuleiro
							$imagemCarta = $_SESSION['cartas'][$i];
						} else{
							$imagemCarta = "question.png";
						}

						echo "<td>";
						echo "<img src='imagens/".$imagemCarta."' id='".$i."' onclick='atualiza(this.id)'>";
						echo "</td>";
					}
				?>
			</tr>
		</table>
		<br/>

		<input type="button" value="Reset" onclick="reseta()"/>

		<?php echo"Jogadas: ".$_SESSION['jogadas'];?>

	</form>
</body>
</html>

<script type="text/javascript">
	// se 2 cartas viradas forem da mesma imagem, forma o par
	<?php
		if ($_SESSION['cartaVirada2'] > -1) {
			if ($_SESSION['cartas'][$_SESSION['cartaVirada1']] == $_SESSION['cartas'][$_SESSION['cartaVirada2']]) {
				$_SESSION['paresFormados'][$_SESSION['cartaVirada1']] = 1;
				$_SESSION['paresFormados'][$_SESSION['cartaVirada2']] = 1;
			} else{
				
			}
		}
	?>
</script>
